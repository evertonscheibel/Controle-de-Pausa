import { Router } from 'express';
import { createSector, listSectors, updateSector } from '../controllers/sectorController.js';

const router = Router();

router.get('/', listSectors);
router.post('/', createSector);
router.put('/:id', updateSector);

export default router;
