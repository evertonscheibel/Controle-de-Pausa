import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import dashboardRoutes from './routes/dashboardRoutes.js';
import sectorRoutes from './routes/sectorRoutes.js';
import { pool } from './db/pool.js';

dotenv.config();

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') ?? '*' }));
app.use(express.json());

app.get('/api/health', async (_req, res) => {
  const dbCheck = await pool.query('select now() as server_time');
  res.json({ ok: true, service: 'bridge-pausecontrol-backend', database: 'postgresql', serverTime: dbCheck.rows[0].server_time });
});

app.use('/api/dashboard', dashboardRoutes);
app.use('/api/sectors', sectorRoutes);

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ ok: false, message: 'Unhandled server error', error: error.message });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Bridge PauseControl backend running on port ${port}`);
});
