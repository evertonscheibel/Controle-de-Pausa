import { query } from '../db/pool.js';
import { serverError } from '../lib/httpErrors.js';

export async function getDashboardSummary(_req, res) {
  try {
    const sql = `
      with schedule_stats as (
        select
          count(*)::int as planned_total,
          count(*) filter (where status = 'completed')::int as completed_total,
          count(*) filter (where status = 'in_progress')::int as in_progress_total,
          count(*) filter (where status = 'delayed')::int as delayed_total,
          count(*) filter (where status = 'not_completed')::int as not_completed_total
        from break_schedules
        where schedule_date = current_date
      ),
      exception_stats as (
        select count(*)::int as exception_total
        from break_exceptions
        where created_at::date = current_date
      )
      select
        planned_total,
        completed_total,
        in_progress_total,
        delayed_total,
        not_completed_total,
        exception_total,
        case when planned_total = 0 then 0
             else round((completed_total::numeric / planned_total::numeric) * 100, 2)
        end as compliance_rate
      from schedule_stats, exception_stats
    `;

    const { rows } = await query(sql);
    res.json({ ok: true, data: rows[0] ?? {} });
  } catch (error) {
    return serverError(res, error, 'Failed to load dashboard summary');
  }
}
