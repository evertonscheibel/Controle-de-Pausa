import { z } from 'zod';
import { query } from '../db/pool.js';
import { badRequest, notFound, serverError } from '../lib/httpErrors.js';

const sectorSchema = z.object({
  name: z.string().min(2),
  code: z.string().min(1),
  unitName: z.string().min(2),
  isActive: z.boolean().optional().default(true)
});

export async function listSectors(_req, res) {
  try {
    const { rows } = await query(`
      select id, name, code, unit_name as "unitName", is_active as "isActive", created_at as "createdAt"
      from sectors
      order by name asc
    `);

    return res.json({ ok: true, data: rows });
  } catch (error) {
    return serverError(res, error, 'Failed to list sectors');
  }
}

export async function createSector(req, res) {
  try {
    const parsed = sectorSchema.safeParse(req.body);
    if (!parsed.success) {
      return badRequest(res, 'Invalid sector payload', parsed.error.flatten());
    }

    const { name, code, unitName, isActive } = parsed.data;

    const { rows } = await query(
      `
        insert into sectors (name, code, unit_name, is_active)
        values ($1, $2, $3, $4)
        returning id, name, code, unit_name as "unitName", is_active as "isActive", created_at as "createdAt"
      `,
      [name, code, unitName, isActive]
    );

    return res.status(201).json({ ok: true, data: rows[0] });
  } catch (error) {
    return serverError(res, error, 'Failed to create sector');
  }
}

export async function updateSector(req, res) {
  try {
    const sectorId = Number(req.params.id);
    if (!Number.isInteger(sectorId)) {
      return badRequest(res, 'Invalid sector id');
    }

    const parsed = sectorSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      return badRequest(res, 'Invalid sector payload', parsed.error.flatten());
    }

    const existing = await query('select id from sectors where id = $1', [sectorId]);
    if (existing.rowCount === 0) {
      return notFound(res, 'Sector not found');
    }

    const current = await query(
      'select name, code, unit_name as "unitName", is_active as "isActive" from sectors where id = $1',
      [sectorId]
    );

    const next = { ...current.rows[0], ...parsed.data };

    const { rows } = await query(
      `
        update sectors
        set name = $1,
            code = $2,
            unit_name = $3,
            is_active = $4,
            updated_at = now()
        where id = $5
        returning id, name, code, unit_name as "unitName", is_active as "isActive", updated_at as "updatedAt"
      `,
      [next.name, next.code, next.unitName, next.isActive, sectorId]
    );

    return res.json({ ok: true, data: rows[0] });
  } catch (error) {
    return serverError(res, error, 'Failed to update sector');
  }
}
