import { query, pool } from './pool.js';

async function seed() {
  await query(`
    insert into sectors (name, code, unit_name)
    values
      ('Desossa Bovinos', 'DES', 'Frigorífico Matriz'),
      ('Abate Bovinos', 'ABA', 'Frigorífico Matriz')
    on conflict (code) do nothing
  `);

  console.log('Seed executed successfully.');
  await pool.end();
}

seed().catch(async (error) => {
  console.error('Seed failed:', error);
  await pool.end();
  process.exit(1);
});
