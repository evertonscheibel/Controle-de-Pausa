# Product Spec — Bridge PauseControl

## Proposta de valor
Sistema de gestão de pausas térmicas e psicofisiológicas com foco em conformidade operacional, rastreabilidade e evidência auditável.

## Problemas que resolve
- ausência de registro confiável
- inconsistência entre líderes
- passivo trabalhista
- baixa visibilidade operacional
- falta de histórico para RH, SESMT e Jurídico

## Escopo funcional
- controle por equipe/turma
- programação automática de pausas
- apontamento rápido
- gestão de exceções
- relatórios gerenciais e jurídicos
- trilha de auditoria

## Indicadores principais
- conformidade
- pausas no horário
- pausas atrasadas
- pausas não realizadas
- atraso médio de início
- atraso médio de retorno
- ranking de exceções por setor/líder
