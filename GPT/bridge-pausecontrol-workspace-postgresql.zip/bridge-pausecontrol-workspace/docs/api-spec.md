# API Spec — Bridge PauseControl

## Health
- GET /api/health

## Auth
- POST /api/auth/login
- GET /api/auth/me

## Dashboard
- GET /api/dashboard/summary

## Cadastros
- GET /api/sectors
- POST /api/sectors
- PUT /api/sectors/:id
- GET /api/teams
- POST /api/teams
- PUT /api/teams/:id
- GET /api/employees
- POST /api/employees
- PUT /api/employees/:id
- GET /api/break-types
- POST /api/break-types
- PUT /api/break-types/:id
- GET /api/break-locations
- POST /api/break-locations
- PUT /api/break-locations/:id
- GET /api/shifts
- POST /api/shifts
- PUT /api/shifts/:id
- GET /api/users
- POST /api/users
- PUT /api/users/:id

## Regras
- GET /api/break-rules
- POST /api/break-rules
- PUT /api/break-rules/:id

## Programação
- GET /api/break-schedules
- POST /api/break-schedules/generate
- POST /api/break-schedules
- PUT /api/break-schedules/:id
- POST /api/break-schedules/:id/reprogram

## Operação
- POST /api/break-executions/start
- POST /api/break-executions/end
- POST /api/break-exceptions

## Relatórios
- GET /api/reports/compliance
- GET /api/reports/exceptions
- GET /api/reports/audit

## Auditoria
- GET /api/audit-logs
