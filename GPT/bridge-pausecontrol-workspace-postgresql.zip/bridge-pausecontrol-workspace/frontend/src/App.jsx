import { Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import DashboardPage from './pages/DashboardPage';
import ProgramacaoPage from './pages/ProgramacaoPage';
import OperacaoPage from './pages/OperacaoPage';
import ExcecoesPage from './pages/ExcecoesPage';

export default function App() {
  return (
    <MainLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/programacao" element={<ProgramacaoPage />} />
        <Route path="/operacao" element={<OperacaoPage />} />
        <Route path="/excecoes" element={<ExcecoesPage />} />
      </Routes>
    </MainLayout>
  );
}
