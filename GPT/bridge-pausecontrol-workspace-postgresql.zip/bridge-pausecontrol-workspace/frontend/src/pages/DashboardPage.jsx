import MetricCard from '../components/MetricCard';

export default function DashboardPage() {
  const metrics = [
    ['Pausas Previstas', '42', 'Turno manhã'],
    ['Em Andamento', '3', 'Monitoramento ao vivo'],
    ['Concluídas', '29', 'Execução validada'],
    ['Exceções', '4', 'Requer análise']
  ];

  return (
    <section>
      <h1>Dashboard Executivo</h1>
      <p>Visão operacional e de conformidade das pausas térmicas e psicofisiológicas.</p>
      <div className="grid metrics-grid">
        {metrics.map(([title, value, helper]) => (
          <MetricCard key={title} title={title} value={value} helper={helper} />
        ))}
      </div>
      <div className="card">
        <h2>Resumo do dia</h2>
        <p>Esta tela é a base inicial. O Antigravity deve evoluir para gráficos, filtros, ranking e alertas em tempo real.</p>
      </div>
    </section>
  );
}
