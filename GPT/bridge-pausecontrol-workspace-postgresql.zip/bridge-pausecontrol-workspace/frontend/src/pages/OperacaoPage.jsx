export default function OperacaoPage() {
  return (
    <section>
      <h1>Operação no Chão de Fábrica</h1>
      <div className="grid actions-grid">
        <button className="action-button">Iniciar Pausa</button>
        <button className="action-button">Encerrar Pausa</button>
        <button className="action-button">Registrar Exceção</button>
        <button className="action-button">Reprogramar</button>
      </div>
    </section>
  );
}
