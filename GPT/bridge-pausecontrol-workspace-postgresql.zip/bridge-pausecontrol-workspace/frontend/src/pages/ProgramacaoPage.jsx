export default function ProgramacaoPage() {
  return (
    <section>
      <h1>Programação de Pausas</h1>
      <div className="card">
        <p>
          Evoluir esta tela para agenda operacional diária com geração automática por regra,
          distribuição por equipe, edição manual e prevenção de conflitos.
        </p>
      </div>
    </section>
  );
}
