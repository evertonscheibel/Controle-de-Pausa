export default function ExcecoesPage() {
  return (
    <section>
      <h1>Gestão de Exceções</h1>
      <div className="card">
        <p>
          Evoluir para tabela com filtros, status, motivo padronizado, responsável, tratamento e trilha de auditoria.
        </p>
      </div>
    </section>
  );
}
